var formPendaftaran = document.getElementById('formPendaftaran');
var hasilNama = document.getElementById('hasilNama');
var hasilNim = document.getElementById('hasilNim');
var hasilJurusan = document.getElementById('hasilJurusan');
var hasilAlamat = document.getElementById('hasilAlamat');

document.getElementById('submit').addEventListener('click', function() {
  hasilNama.textContent = document.getElementById('nama').value;
  hasilNim.textContent = document.getElementById('nim').value;
  hasilJurusan.textContent = document.getElementById('jurusan').value;
  hasilAlamat.textContent = document.getElementById('alamat').value;
});
